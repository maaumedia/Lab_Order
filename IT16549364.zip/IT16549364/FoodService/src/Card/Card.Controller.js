var mongoose        = require('../DBSchema/SchemaMapper');
var CardSchema 		= mongoose.model('Card');

var CardController = function(){
    this.insert = function(data)  {
        return new Promise(function(resolve, reject)  {
            var card = new CardSchema({
                cardNumber: data.cardNumber,
                cvcNumber: data.cvcNumber
            });
            card.save().then(function()  {
                resolve({status: 200, message: "Added your card"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- "+err});
            })
        })

    }

    this.update = function(id, data)  {
        return new Promise(function(resolve, reject)  {
            CardSchema.update({_id: id}, data).then(function()  {
                resolve({status: 200, message: "update Card Info"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.searchAll = function()  {
        return new Promise(function(resolve, reject)  {
            CardSchema.find().exec().then(function(data)  {
                resolve({status: 200, data: data});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.search = function(id)  {
        return new Promise(function(resolve, reject)  {
            CardSchema.find({_id:id}).exec().then(function(card)  {
                resolve({status: 200, data: card});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.delete = function(id)  {
        return new Promise(function(resolve, reject)  {
            CardSchema.remove({_id:id}).then(function()  {
                resolve({status: 200, message: "remove your card"});
            }).catch(function(err)  {
                reject({status: 500, message:"Error:- " + err});
            })
        })
    }
}

module.exports = new CardController();