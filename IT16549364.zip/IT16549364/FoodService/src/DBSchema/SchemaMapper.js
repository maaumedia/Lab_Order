
var mongoose 		= require('mongoose');
const Schema        = mongoose.Schema;

const FoodSchema = new Schema({
    foodName: {
        type: String,
        require: true
    },

    price:{
        type:Number,
        require:true
    },

    loyaltyPoints: {
        type: Number,
        require: true
    }
});

const OrderSchema = new Schema({

    itemName: [
        {
        type: String,
        require:true
        }
    ],
    quantity:{
            type: Number,
            require:true
        },

     Totprice:{
        type:Number,
         require:true
     }

});

const CardSchema = new Schema({
    cardNumber: {
        type: String,
        require: true
    },

    cvcNumber:{
        type:Number,
        require:true
    },


});

const MobileSchema = new Schema({
    mobileNumber: {
        type: String,
        require: true
    },

    pinNumber:{
        type:Number,
        require:true
    },


});

const PaymentSchema = new Schema({

    OrderId: [
        {
            type: Schema.Types.ObjectId,
            ref: 'Order'
        }
    ],

    Totprice:[{
        type:Schema.Types.ObjectId,
        ref:'Order'
    }],

    CardId:[{
        type:Schema.Types.ObjectId,
        ref:'Card'
    }]

});



mongoose.model('Food', FoodSchema);
mongoose.model('Order', OrderSchema);
mongoose.model('Payment', PaymentSchema);
mongoose.model('Card', CardSchema);
mongoose.model('Mobile', MobileSchema);

mongoose.connect('mongodb://127.0.0.1:27017/foodservice', function(err) {
    if (err) {
        console.log(err);
        process.exit(-1);
    }
    console.log('Connected to the DB');
});

module.exports = mongoose;