var mongoose        = require('../DBSchema/SchemaMapper');
var OrderSchema 		= mongoose.model('Order');

var OrderController = function(){
    this.insert = function(data)  {
        return new Promise(function(resolve, reject)  {
            var order = new OrderSchema({
                itemName: data.itemName,
                quantity: data.quantity,
                price:data.price
            });
            order.save().then(function()  {
                resolve({status: 200, message: "Added new order"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- "+err});
            })
        })

    }

    this.update = function(id, data)  {
        return new Promise(function(resolve, reject)  {
            OrderSchema.update({_id: id}, data).then(function()  {
                resolve({status: 200, message: "update order"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.searchAll = function()  {
        return new Promise(function(resolve, reject)  {
            OrderSchema.find().exec().then(function(data)  {
                resolve({status: 200, data: data});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.search = function(id)  {
        return new Promise(function(resolve, reject)  {
            OrderSchema.find({_id:id}).exec().then(function(user)  {
                resolve({status: 200, data: order});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.delete = function(id)  {
        return new Promise(function(resolve, reject)  {
            OrderSchema.remove({_id:id}).then(function()  {
                resolve({status: 200, message: "remove order"});
            }).catch(function(err)  {
                reject({status: 500, message:"Error:- " + err});
            })
        })
    }
}

module.exports = new OrderController();