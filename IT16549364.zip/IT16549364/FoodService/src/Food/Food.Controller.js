var mongoose        = require('../DBSchema/SchemaMapper');
var FoodSchema 		= mongoose.model('Food');

var FoodController = function(){
    this.insert = function(data)  {
        return new Promise(function(resolve, reject)  {
                var food = new FoodSchema({
                    foodName: data.foodName,
                    price: data.price,
                    loyaltyPoints:data.loyaltyPoints
                });
        food.save().then(function()  {
            resolve({status: 200, message: "Added new food"});
    }).catch(function(err)  {
            reject({status: 500, message: "Error:- "+err});
    })
    })

    }

    this.update = function(id, data)  {
        return new Promise(function(resolve, reject)  {
                FoodSchema.update({_id: id}, data).then(function()  {
                resolve({status: 200, message: "update food"});
    }).catch(function(err)  {
            reject({status: 500, message: "Error:- " + err});
    })
    })
    }

    this.searchAll = function()  {
        return new Promise(function(resolve, reject)  {
                FoodSchema.find().exec().then(function(data)  {
                resolve({status: 200, data: data});
    }).catch(function(err)  {
            reject({status: 500, message: "Error:- " + err});
    })
    })
    }

    this.search = function(id)  {
        return new Promise(function(resolve, reject)  {
                FoodSchema.find({_id:id}).exec().then(function(food)  {
                resolve({status: 200, data: food});
    }).catch(function(err)  {
            reject({status: 500, message: "Error:- " + err});
    })
    })
    }

    this.delete = function(id)  {
        return new Promise(function(resolve, reject)  {
                FoodSchema.remove({_id:id}).then(function()  {
                resolve({status: 200, message: "remove food"});
    }).catch(function(err)  {
            reject({status: 500, message:"Error:- " + err});
    })
    })
    }
}

module.exports = new FoodController();