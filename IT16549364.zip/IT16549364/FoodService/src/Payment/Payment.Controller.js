
var mongoose        = require('../DBSchema/SchemaMapper');
var PaymentSchema 		= mongoose.model('Payment');

var PaymentController = function(){
    this.insert = function(data)  {
        return new Promise(function(resolve, reject)  {
            var payment = new PaymentSchema({
                OrderID: data.OrderId,
                Totprice: data.price,
                CardId:data.CardId
            });
            payment.save().then(function()  {
                resolve({status: 200, message: "Added payment"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- "+err});
            })
        })

    }


    this.searchAll = function()  {
        return new Promise(function(resolve, reject)  {
            PaymentSchema.find().exec().then(function(data)  {
                resolve({status: 200, data: data});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.search = function(id)  {
        return new Promise(function(resolve, reject)  {
            PaymentSchema.find({_id:id}).exec().then(function(payment)  {
                resolve({status: 200, data: payment});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.delete = function(id)  {
        return new Promise(function(resolve, reject)  {
            PaymentSchema.remove({_id:id}).then(function()  {
                resolve({status: 200, message: "remove payment"});
            }).catch(function(err)  {
                reject({status: 500, message:"Error:- " + err});
            })
        })
    }
}

module.exports = new PaymentController();
