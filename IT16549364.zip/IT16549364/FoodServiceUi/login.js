var attemptsss = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function valid(){
var user = document.getElementById("user1").value;
var pass = document.getElementById("pass1").value;
if ( user == "Akila" && pass == "321"){
alert ("Logged in to MAAU's Fast Food successfully");
window.location = "index.html"; // Redirecting to other page.
return false;
}
else{
attempts --;// Decrementing by one.
alert("You have left "+attemptss+" attempts;");
// Disabling fields after 3 attempts.
if( attemptsss == 0){
document.getElementById("user1").disabled = true;
document.getElementById("pass1").disabled = true;
document.getElementById("submit1").disabled = true;
return false;
}
}
}
