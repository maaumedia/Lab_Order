var mongoose        = require('../DBSchema/SchemaMapper');
var MobileSchema 		= mongoose.model('Mobile');

var MobileController = function(){
    this.insert = function(data)  {
        return new Promise(function(resolve, reject)  {
            var mobile = new MobileSchema({
                mobileNumber: data.mobileNumber,
                pinNumber: data.pinNumber
            });
            mobile.save().then(function()  {
                resolve({status: 200, message: "Added your mobile"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- "+err});
            })
        })

    }

    this.update = function(id, data)  {
        return new Promise(function(resolve, reject)  {
            MobileSchema.update({_id: id}, data).then(function()  {
                resolve({status: 200, message: "update Mobile Info"});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.searchAll = function()  {
        return new Promise(function(resolve, reject)  {
            MobileSchema.find().exec().then(function(data)  {
                resolve({status: 200, data: data});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.search = function(id)  {
        return new Promise(function(resolve, reject)  {
            MobileSchema.find({_id:id}).exec().then(function(mobile)  {
                resolve({status: 200, data: mobile});
            }).catch(function(err)  {
                reject({status: 500, message: "Error:- " + err});
            })
        })
    }

    this.delete = function(id)  {
        return new Promise(function(resolve, reject)  {
            MobileSchema.remove({_id:id}).then(function()  {
                resolve({status: 200, message: "remove your mobile"});
            }).catch(function(err)  {
                reject({status: 500, message:"Error:- " + err});
            })
        })
    }
}

module.exports = new MobileController();
