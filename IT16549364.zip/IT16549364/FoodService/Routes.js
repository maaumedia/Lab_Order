
var Express         = require("express");
var Routes          = Express.Router();
var FoodRoute       = require('./src/Food/Food.Route');
var OrderRoute    = require('./src/Order/Order.Route');
var CardRoute    = require('./src/Card/Card.Route');
var PaymentRoute    = require('./src/Payment/Payment.Route');

Routes.use('/food/', FoodRoute);
Routes.use('/order/', OrderRoute);
Routes.use('/card/', CardRoute);
Routes.use('/payment/', PaymentRoute);

module.exports = Routes;
